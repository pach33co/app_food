import { FornecedoresRepository } from "../repository/fornecedores.repositorio.js";
import { FornecedorModel } from "../models/fornecedores.model.js";
import { StatusFornecedor } from "../enum/fornecedores.enum.js";

export class FornecedoresService 
{
  static async listar() 
  {
    return await FornecedoresRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await FornecedoresRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new FornecedorModel(
      0,
      data.razao_social,
      data.nome_fantasia,
      data.cnpj,
      data.email,
      data.telefone,
      data.endereco,
      data.status ?? StatusFornecedor.ATIVO
    );

    const id = await FornecedoresRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await FornecedoresRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new FornecedorModel(
      Number(id),
      data.razao_social ?? atual.razao_social,
      data.nome_fantasia ?? atual.nome_fantasia,
      data.cnpj ?? atual.cnpj,
      data.email ?? atual.email,
      data.telefone ?? atual.telefone,
      data.endereco ?? atual.endereco,
      data.status ?? atual.status
    );

    const updated = await FornecedoresRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await FornecedoresRepository.remover(Number(id));
  }
}
