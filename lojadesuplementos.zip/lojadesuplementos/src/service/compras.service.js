import { ComprasRepository } from "../repository/compras.repositorio.js";
import { CompraModel } from "../models/compras.model.js";
import { StatusCompra } from "../enum/compras.enum.js";

export class ComprasService 
{
  static async listar() 
  {
    return await ComprasRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ComprasRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new CompraModel(
      0,
      data.data_compra,
      data.id_fornecedor,
      data.valor_total ?? 0,
      data.status ?? StatusCompra.PENDENTE
    );

    const id = await ComprasRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await ComprasRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new CompraModel(
      Number(id),
      data.data_compra ?? atual.data_compra,
      data.id_fornecedor ?? atual.id_fornecedor,
      data.valor_total ?? atual.valor_total,
      data.status ?? atual.status
    );

    const updated = await ComprasRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ComprasRepository.remover(Number(id));
  }
}
