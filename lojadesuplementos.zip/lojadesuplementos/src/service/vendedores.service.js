import { VendedoresRepository } from "../repository/vendedores.repositorio.js";
import { VendedorModel } from "../models/vendedores.model.js";
import { StatusVendedor } from "../enum/vendedores.enum.js";

export class VendedoresService 
{
  static async listar() 
  {
    return await VendedoresRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await VendedoresRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new VendedorModel(
      0,
      data.nome,
      data.email,
      data.telefone,
      data.comissao_percentual,
      data.data_admissao,
      data.status ?? StatusVendedor.ATIVO
    );

    const id = await VendedoresRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await VendedoresRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new VendedorModel(
      Number(id),
      data.nome ?? atual.nome,
      data.email ?? atual.email,
      data.telefone ?? atual.telefone,
      data.comissao_percentual ?? atual.comissao_percentual,
      data.data_admissao ?? atual.data_admissao,
      data.status ?? atual.status
    );

    const updated = await VendedoresRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await VendedoresRepository.remover(Number(id));
  }
}
