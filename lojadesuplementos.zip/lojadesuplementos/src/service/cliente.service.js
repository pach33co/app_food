import { ClienteRepository } from "../repository/cliente.repositorio.js";
import { ClienteModel } from "../models/clientes.model.js";
import { PerfilCliente } from "../enum/cliente.enum.js";

export class ClienteService 
{
  static async listar() 
  {
    return await ClienteRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ClienteRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new ClienteModel(
      0,
      data.nome,
      data.email,
      data.telefone,
      data.Endereco,
      data.perfil ?? PerfilCliente.CLIENTE
    );

    const id = await ClienteRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await ClienteRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new ClienteModel(
      Number(id),
      data.nome ?? atual.nome,
      data.email ?? atual.email,
      data.telefone ?? atual.telefone,
      data.Endereco ?? atual.Endereco,
      data.perfil ?? atual.perfil
    );

    const updated = await ClienteRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ClienteRepository.remover(Number(id));
  }
}
