import { ItensVendaRepository } from "../repository/itensvenda.repositorio.js";
import { ItemVendaModel } from "../models/itensvenda.model.js";

export class ItensVendaService 
{
  static async listar() 
  {
    return await ItensVendaRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ItensVendaRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new ItemVendaModel(
      0,
      data.id_venda,
      data.id_produto,
      data.quantidade,
      data.preco_unitario
    );

    const id = await ItensVendaRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await ItensVendaRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new ItemVendaModel(
      Number(id),
      data.id_venda ?? atual.id_venda,
      data.id_produto ?? atual.id_produto,
      data.quantidade ?? atual.quantidade,
      data.preco_unitario ?? atual.preco_unitario
    );

    const updated = await ItensVendaRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ItensVendaRepository.remover(Number(id));
  }
}
