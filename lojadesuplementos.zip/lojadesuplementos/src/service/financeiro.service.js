import { FinanceiroRepository } from "../repository/financeiro.repositorio.js";
import { FinanceiroModel } from "../models/financeiro.model.js";
import { StatusFinanceiro, TipoFinanceiro } from "../enum/financeiro.enum.js";

export class FinanceiroService 
{

  static async buscarValorTotal() 
  {
    return await FinanceiroRepository.buscarValorTotal();
  }


  static async listar() 
  {
    return await FinanceiroRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await FinanceiroRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new FinanceiroModel(
      0,
      data.tipo ?? TipoFinanceiro.RECEITA,
      data.categoria,
      data.descricao,
      data.valor,
      data.data_vencimento,
      data.data_pagamento,
      data.status ?? StatusFinanceiro.PENDENTE,
      data.id_venda,
      data.id_compra,
      data.id_cliente,
      data.id_fornecedor
    );

    const id = await FinanceiroRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await FinanceiroRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new FinanceiroModel(
      Number(id),
      data.tipo ?? atual.tipo,
      data.categoria ?? atual.categoria,
      data.descricao ?? atual.descricao,
      data.valor ?? atual.valor,
      data.data_vencimento ?? atual.data_vencimento,
      data.data_pagamento ?? atual.data_pagamento,
      data.status ?? atual.status,
      data.id_venda ?? atual.id_venda,
      data.id_compra ?? atual.id_compra,
      data.id_cliente ?? atual.id_cliente,
      data.id_fornecedor ?? atual.id_fornecedor
    );

    const updated = await FinanceiroRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await FinanceiroRepository.remover(Number(id));
  }
}
