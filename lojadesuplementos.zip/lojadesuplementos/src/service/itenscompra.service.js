import { ItensCompraRepository } from "../repository/itenscompra.repositorio.js";
import { ItemCompraModel } from "../models/itenscompra.model.js";

export class ItensCompraService 
{
  static async listar() 
  {
    return await ItensCompraRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ItensCompraRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new ItemCompraModel(
      0,
      data.id_compra,
      data.id_produto,
      data.quantidade,
      data.preco_custo_unitario
    );

    const id = await ItensCompraRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await ItensCompraRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new ItemCompraModel(
      Number(id),
      data.id_compra ?? atual.id_compra,
      data.id_produto ?? atual.id_produto,
      data.quantidade ?? atual.quantidade,
      data.preco_custo_unitario ?? atual.preco_custo_unitario
    );

    const updated = await ItensCompraRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ItensCompraRepository.remover(Number(id));
  }
}
