import { VendasRepository } from "../repository/vendas.repositorio.js";
import { VendaModel } from "../models/vendas.model.js";
import { FormaPagamentoVenda, StatusVenda } from "../enum/vendas.enum.js";

export class VendasService 
{
  static async listar() 
  {
    return await VendasRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await VendasRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new VendaModel(
      0,
      data.data_venda,
      data.id_cliente,
      data.id_vendedor,
      data.valor_total ?? 0,
      data.forma_pagamento ?? FormaPagamentoVenda.DINHEIRO,
      data.status ?? StatusVenda.PENDENTE
    );

    const id = await VendasRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await VendasRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new VendaModel(
      Number(id),
      data.data_venda ?? atual.data_venda,
      data.id_cliente ?? atual.id_cliente,
      data.id_vendedor ?? atual.id_vendedor,
      data.valor_total ?? atual.valor_total,
      data.forma_pagamento ?? atual.forma_pagamento,
      data.status ?? atual.status
    );

    const updated = await VendasRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await VendasRepository.remover(Number(id));
  }
}
