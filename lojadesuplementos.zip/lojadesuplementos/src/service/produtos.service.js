import { ProdutosRepository } from "../repository/produtos.repositorio.js";
import { ProdutoModel } from "../models/produtos.model.js";
import { StatusProduto } from "../enum/produtos.enum.js";

export class ProdutosService 
{

  static async buscarValorTotalEstoque() 
  {
    return await ProdutosRepository.buscarValorTotalEstoque();
  }


  static async listar() 
  {
    return await ProdutosRepository.listar();
  }

  static async buscarPorId(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ProdutosRepository.buscarPorId(Number(id));
  }

  static async criar(data) 
  {
    const item = new ProdutoModel(
      0,
      data.nome,
      data.descricao,
      data.preco_custo,
      data.preco_venda,
      data.estoque,
      data.unidade,
      data.id_fornecedor,
      data.status ?? StatusProduto.ATIVO
    );

    const id = await ProdutosRepository.criar(item);

    return await this.buscarPorId(id);
  }

  static async atualizar(id, data) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    const atual = await ProdutosRepository.buscarPorId(Number(id));

    if (!atual) 
    {
      return null;
    }

    const item = new ProdutoModel(
      Number(id),
      data.nome ?? atual.nome,
      data.descricao ?? atual.descricao,
      data.preco_custo ?? atual.preco_custo,
      data.preco_venda ?? atual.preco_venda,
      data.estoque ?? atual.estoque,
      data.unidade ?? atual.unidade,
      data.id_fornecedor ?? atual.id_fornecedor,
      data.status ?? atual.status
    );

    const updated = await ProdutosRepository.atualizar(Number(id), item);

    if (!updated) 
    {
      return null;
    }

    return await this.buscarPorId(Number(id));
  }

  static async remover(id) 
  {
    if (!Number.isInteger(Number(id)) || Number(id) <= 0) 
    {
      throw new Error("Id inválido");
    }

    return await ProdutosRepository.remover(Number(id));
  }
}
