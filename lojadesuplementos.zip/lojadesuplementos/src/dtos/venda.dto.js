export class VendaDTO 
{
  static toResponse(venda) 
  {
    return {
      id: venda.id,
      data_venda: venda.data_venda,
      id_cliente: venda.id_cliente,
      id_vendedor: venda.id_vendedor,
      valor_total: venda.valor_total,
      forma_pagamento: venda.forma_pagamento,
      status: venda.status
    };
  }
}
