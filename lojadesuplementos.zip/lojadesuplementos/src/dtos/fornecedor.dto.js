export class FornecedorDTO 
{
  static toResponse(fornecedor) 
  {
    return {
      id: fornecedor.id,
      razao_social: fornecedor.razao_social,
      nome_fantasia: fornecedor.nome_fantasia,
      cnpj: fornecedor.cnpj,
      email: fornecedor.email,
      telefone: fornecedor.telefone,
      endereco: fornecedor.endereco,
      status: fornecedor.status
    };
  }
}
