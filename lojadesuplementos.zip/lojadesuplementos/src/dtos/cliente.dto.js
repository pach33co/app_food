export class ClienteDTO 
{
  static toResponse(cliente) 
  {
    return {
      id: cliente.id,
      nome: cliente.nome,
      email: cliente.email,
      telefone: cliente.telefone,
      Endereco: cliente.Endereco,
      perfil: cliente.perfil
    };
  }
}
