export class FinanceiroDTO 
{
  static toResponse(financeiro) 
  {
    return {
      id: financeiro.id,
      tipo: financeiro.tipo,
      categoria: financeiro.categoria,
      descricao: financeiro.descricao,
      valor: financeiro.valor,
      data_vencimento: financeiro.data_vencimento,
      data_pagamento: financeiro.data_pagamento,
      status: financeiro.status,
      id_venda: financeiro.id_venda,
      id_compra: financeiro.id_compra,
      id_cliente: financeiro.id_cliente,
      id_fornecedor: financeiro.id_fornecedor
    };
  }
}
