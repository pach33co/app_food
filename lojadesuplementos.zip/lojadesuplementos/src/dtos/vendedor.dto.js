export class VendedorDTO 
{
  static toResponse(vendedor) 
  {
    return {
      id: vendedor.id,
      nome: vendedor.nome,
      email: vendedor.email,
      telefone: vendedor.telefone,
      comissao_percentual: vendedor.comissao_percentual,
      data_admissao: vendedor.data_admissao,
      status: vendedor.status
    };
  }
}
