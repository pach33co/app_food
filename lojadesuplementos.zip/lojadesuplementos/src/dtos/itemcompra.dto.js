export class ItemCompraDTO 
{
  static toResponse(item) 
  {
    return {
      id: item.id,
      id_compra: item.id_compra,
      id_produto: item.id_produto,
      quantidade: item.quantidade,
      preco_custo_unitario: item.preco_custo_unitario,
      subtotal: item.subtotal
    };
  }
}
