export class ProdutoDTO 
{
  static toResponse(produto) 
  {
    return {
      id: produto.id,
      nome: produto.nome,
      descricao: produto.descricao,
      preco_custo: produto.preco_custo,
      preco_venda: produto.preco_venda,
      estoque: produto.estoque,
      unidade: produto.unidade,
      id_fornecedor: produto.id_fornecedor,
      status: produto.status
    };
  }
}
