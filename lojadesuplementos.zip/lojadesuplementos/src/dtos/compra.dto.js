export class CompraDTO 
{
  static toResponse(compra) 
  {
    return {
      id: compra.id,
      data_compra: compra.data_compra,
      id_fornecedor: compra.id_fornecedor,
      valor_total: compra.valor_total,
      status: compra.status
    };
  }
}
