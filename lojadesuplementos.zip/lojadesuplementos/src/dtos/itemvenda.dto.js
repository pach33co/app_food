export class ItemVendaDTO 
{
  static toResponse(item) 
  {
    return {
      id: item.id,
      id_venda: item.id_venda,
      id_produto: item.id_produto,
      quantidade: item.quantidade,
      preco_unitario: item.preco_unitario,
      subtotal: item.subtotal
    };
  }
}
