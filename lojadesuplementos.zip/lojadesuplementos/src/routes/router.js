import { Router } from "express";
import clienteRouter from "./cliente.routes.js";
import fornecedoresRouter from "./fornecedores.routes.js";
import produtosRouter from "./produtos.routes.js";
import vendedoresRouter from "./vendedores.routes.js";
import vendasRouter from "./vendas.routes.js";
import itensvendaRouter from "./itensvenda.routes.js";
import comprasRouter from "./compras.routes.js";
import itenscompraRouter from "./itenscompra.routes.js";
import financeiroRouter from "./financeiro.routes.js";

const router = Router();

router.get("/", (req, res) => {
  return res.status(200).json({ status: "ok" });
});

router.use("/cliente", clienteRouter);
router.use("/fornecedores", fornecedoresRouter);
router.use("/produtos", produtosRouter);
router.use("/vendedores", vendedoresRouter);
router.use("/vendas", vendasRouter);
router.use("/itensvenda", itensvendaRouter);
router.use("/compras", comprasRouter);
router.use("/itenscompra", itenscompraRouter);
router.use("/financeiro", financeiroRouter);

router.use((req, res) => {
  return res.status(404).json({ error: "Rota não encontrada" });
});

export default router;
