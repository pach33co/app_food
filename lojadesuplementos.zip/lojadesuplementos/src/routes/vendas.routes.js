import { Router } from "express";
import { VendasController } from "../controller/vendas.controller.js";

const router = Router();

const controller = new VendasController();

function parseId(value) 
{
  const id = Number(value);
  return Number.isInteger(id) && id > 0 ? id : null;
}

router.post("/", async (req, res) => {
  try 
  {
    const result = await controller.criar({
      body: req.body
    });

    if (!result || typeof result.statusCode !== "number") 
    {
      return res.status(500).json({ error: "Resposta inválida do controller" });
    }

    if (result.statusCode === 204) 
    {
      return res.sendStatus(204);
    }

    return res.status(result.statusCode).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

router.get("/", async (req, res) => {
  try 
  {
    const result = await controller.listar();

    if (!result || typeof result.statusCode !== "number") 
    {
      return res.status(500).json({ error: "Resposta inválida do controller" });
    }

    if (result.statusCode === 204) 
    {
      return res.sendStatus(204);
    }

    return res.status(result.statusCode).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

router.get("/:id", async (req, res) => {
  try 
  {
    const result = await controller.buscarPorId({
      id: parseId(req.params.id)
    });

    if (!result || typeof result.statusCode !== "number") 
    {
      return res.status(500).json({ error: "Resposta inválida do controller" });
    }

    if (result.statusCode === 204) 
    {
      return res.sendStatus(204);
    }

    return res.status(result.statusCode).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

router.put("/:id", async (req, res) => {
  try 
  {
    const result = await controller.atualizar({
      id: parseId(req.params.id),
      body: req.body
    });

    if (!result || typeof result.statusCode !== "number") 
    {
      return res.status(500).json({ error: "Resposta inválida do controller" });
    }

    if (result.statusCode === 204) 
    {
      return res.sendStatus(204);
    }

    return res.status(result.statusCode).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

router.delete("/:id", async (req, res) => {
  try 
  {
    const result = await controller.remover({
      id: parseId(req.params.id)
    });

    if (!result || typeof result.statusCode !== "number") 
    {
      return res.status(500).json({ error: "Resposta inválida do controller" });
    }

    if (result.statusCode === 204) 
    {
      return res.sendStatus(204);
    }

    return res.status(result.statusCode).json(result.body);
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

export default router;
