import { PerfilCliente } from "../enum/cliente.enum.js";

export class ClienteModel 
{
  constructor(id = 0,nome = "",email = "",telefone = "",Endereco = "",perfil = PerfilCliente.CLIENTE) 
  {
    this.id = id;
    this.setNome(nome);
    this.setEmail(email);
    this.setTelefone(telefone);
    this.setEndereco(Endereco);
    this.setPerfil(perfil);
  }

  setNome(nome) 
  {
    const texto = String(nome).trim();

    if (!texto || texto.length < 2 || texto.length > 40) 
    {
      throw new Error("Nome inválido");
    }

    this.nome = texto;
  }

  setEmail(email) 
  {
    const texto = String(email).trim().toLowerCase();
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!texto || !regex.test(texto)) 
    {
      throw new Error("Email inválido");
    }

    this.email = texto;
  }

  setTelefone(telefone) 
  {
    const texto = String(telefone).trim();

    if (!texto || texto.length < 11) 
    {
      throw new Error("Telefone inválido");
    }

    this.telefone = texto;
  }

  setEntrega(Entrega) 
  {
    this.Entrega = Entrega ? String(Entrega).trim() : "";
  }

  setEndereco(Endereco) 
  {
    this.Endereco = Endereco ? String(Endereco).trim() : "";
  }

  setPerfil(perfil) 
  {
    const valor = String(perfil).trim().toUpperCase();

    if (!Object.values(PerfilCliente).includes(valor)) 
    {
      throw new Error("Perfil inválido");
    }

    this.perfil = valor;
  }
}
