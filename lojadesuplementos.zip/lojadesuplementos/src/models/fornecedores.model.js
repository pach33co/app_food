import { StatusFornecedor } from "../enum/fornecedores.enum.js";

export class FornecedorModel 
{
  constructor(id = 0,razao_social = "",nome_fantasia = "",cnpj = "",email = "",telefone = "",endereco = "",status = StatusFornecedor.ATIVO) 
  {
    this.id = id;
    this.setRazaoSocial(razao_social);
    this.setNomeFantasia(nome_fantasia);
    this.setCnpj(cnpj);
    this.setEmail(email);
    this.setTelefone(telefone);
    this.setEndereco(endereco);
    this.setStatus(status);
  }

  setRazaoSocial(razao_social) 
  {
    const texto = String(razao_social).trim();

    if (!texto || texto.length < 2 || texto.length > 100) 
    {
      throw new Error("Razão social inválida");
    }

    this.razao_social = texto;
  }

  setNomeFantasia(nome_fantasia) 
  {
    this.nome_fantasia = nome_fantasia ? String(nome_fantasia).trim() : "";
  }

  setCnpj(cnpj) 
  {
    const texto = String(cnpj).trim();

    if (!texto || texto.length < 14) 
    {
      throw new Error("CNPJ inválido");
    }

    this.cnpj = texto;
  }

  setEmail(email) 
  {
    const texto = String(email).trim().toLowerCase();
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!texto || !regex.test(texto)) 
    {
      throw new Error("Email inválido");
    }

    this.email = texto;
  }

  setTelefone(telefone) 
  {
    const texto = String(telefone).trim();

    if (!texto || texto.length < 10) 
    {
      throw new Error("Telefone inválido");
    }

    this.telefone = texto;
  }

  setEndereco(endereco) 
  {
    this.endereco = endereco ? String(endereco).trim() : "";
  }

  setStatus(status) 
  {
    const valor = String(status).trim().toUpperCase();

    if (!Object.values(StatusFornecedor).includes(valor)) 
    {
      throw new Error("Status inválido");
    }

    this.status = valor;
  }
}
