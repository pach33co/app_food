import { StatusFinanceiro, TipoFinanceiro } from "../enum/financeiro.enum.js";

export class FinanceiroModel 
{
  constructor(id = 0,tipo = TipoFinanceiro.RECEITA,categoria = "",descricao = "",valor = 0,data_vencimento = "",data_pagamento = "",status = StatusFinanceiro.PENDENTE,
    id_venda = null,id_compra = null,id_cliente = null,id_fornecedor = null) 
  {
    this.id = id;
    this.setTipo(tipo);
    this.setCategoria(categoria);
    this.setDescricao(descricao);
    this.setValor(valor);
    this.setDataVencimento(data_vencimento);
    this.setDataPagamento(data_pagamento);
    this.setStatus(status);
    this.setIdVenda(id_venda);
    this.setIdCompra(id_compra);
    this.setIdCliente(id_cliente);
    this.setIdFornecedor(id_fornecedor);
  }

  setTipo(tipo) 
  {
    const valor = String(tipo).trim().toUpperCase();

    if (!Object.values(TipoFinanceiro).includes(valor)) 
    {
      throw new Error("Tipo inválido");
    }

    this.tipo = valor;
  }

  setCategoria(categoria) 
  {
    const texto = String(categoria).trim();

    if (!texto || texto.length < 2) 
    {
      throw new Error("Categoria inválida");
    }

    this.categoria = texto;
  }

  setDescricao(descricao) 
  {
    this.descricao = descricao ? String(descricao).trim() : "";
  }

  setValor(valor) 
  {
    const numero = Number(valor);

    if (!Number.isFinite(numero) || numero < 0) 
    {
      throw new Error("Valor inválido");
    }

    this.valor = numero;
  }

  setDataVencimento(data_vencimento) 
  {
    const texto = String(data_vencimento).trim();

    if (!texto) 
    {
      throw new Error("Data de vencimento inválida");
    }

    this.data_vencimento = texto;
  }

  setDataPagamento(data_pagamento) 
  {
    this.data_pagamento = data_pagamento ? String(data_pagamento).trim() : null;
  }

  setStatus(status) 
  {
    const valor = String(status).trim().toUpperCase();

    if (!Object.values(StatusFinanceiro).includes(valor)) 
    {
      throw new Error("Status inválido");
    }

    this.status = valor;
  }

  setIdVenda(id_venda) 
  {
    if (id_venda === null || id_venda === undefined || id_venda === "") 
    {
      this.id_venda = null;
      return;
    }

    const valor = Number(id_venda);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Venda inválida");
    }

    this.id_venda = valor;
  }

  setIdCompra(id_compra) 
  {
    if (id_compra === null || id_compra === undefined || id_compra === "") 
    {
      this.id_compra = null;
      return;
    }

    const valor = Number(id_compra);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Compra inválida");
    }

    this.id_compra = valor;
  }

  setIdCliente(id_cliente) 
  {
    if (id_cliente === null || id_cliente === undefined || id_cliente === "") 
    {
      this.id_cliente = null;
      return;
    }

    const valor = Number(id_cliente);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Cliente inválido");
    }

    this.id_cliente = valor;
  }

  setIdFornecedor(id_fornecedor) 
  {
    if (id_fornecedor === null || id_fornecedor === undefined || id_fornecedor === "") 
    {
      this.id_fornecedor = null;
      return;
    }

    const valor = Number(id_fornecedor);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Fornecedor inválido");
    }

    this.id_fornecedor = valor;
  }
}
