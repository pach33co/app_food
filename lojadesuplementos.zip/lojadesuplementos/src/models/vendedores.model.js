import { StatusVendedor } from "../enum/vendedores.enum.js";

export class VendedorModel 
{
  constructor(id = 0,nome = "",email = "",telefone = "",comissao_percentual = 5,data_admissao = "",status = StatusVendedor.ATIVO) 
  {
    this.id = id;
    this.setNome(nome);
    this.setEmail(email);
    this.setTelefone(telefone);
    this.setComissaoPercentual(comissao_percentual);
    this.setDataAdmissao(data_admissao);
    this.setStatus(status);
  }

  setNome(nome) 
  {
    const texto = String(nome).trim();

    if (!texto || texto.length < 2 || texto.length > 100) 
    {
      throw new Error("Nome inválido");
    }

    this.nome = texto;
  }

  setEmail(email) 
  {
    const texto = String(email).trim().toLowerCase();
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!texto || !regex.test(texto)) 
    {
      throw new Error("Email inválido");
    }

    this.email = texto;
  }

  setTelefone(telefone) 
  {
    const texto = String(telefone).trim();

    if (!texto || texto.length < 10) 
    {
      throw new Error("Telefone inválido");
    }

    this.telefone = texto;
  }

  setComissaoPercentual(comissao_percentual) 
  {
    const valor = Number(comissao_percentual);

    if (!Number.isFinite(valor) || valor < 0) 
    {
      throw new Error("Comissão inválida");
    }

    this.comissao_percentual = valor;
  }

  setDataAdmissao(data_admissao) 
  {
    const texto = String(data_admissao).trim();

    if (!texto) 
    {
      throw new Error("Data de admissão inválida");
    }

    this.data_admissao = texto;
  }

  setStatus(status) 
  {
    const valor = String(status).trim().toUpperCase();

    if (!Object.values(StatusVendedor).includes(valor)) 
    {
      throw new Error("Status inválido");
    }

    this.status = valor;
  }
}
