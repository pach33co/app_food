import { FormaPagamentoVenda, StatusVenda } from "../enum/vendas.enum.js";

export class VendaModel 
{
  constructor(id = 0,data_venda = "",id_cliente = null,id_vendedor = null,valor_total = 0,forma_pagamento = FormaPagamentoVenda.DINHEIRO,status = StatusVenda.PENDENTE) 
  {
    this.id = id;
    this.setDataVenda(data_venda);
    this.setIdCliente(id_cliente);
    this.setIdVendedor(id_vendedor);
    this.setValorTotal(valor_total);
    this.setFormaPagamento(forma_pagamento);
    this.setStatus(status);
  }

  setDataVenda(data_venda) 
  {
    this.data_venda = data_venda ? String(data_venda).trim() : "";
  }

  setIdCliente(id_cliente) 
  {
    if (id_cliente === null || id_cliente === undefined || id_cliente === "") 
    {
      this.id_cliente = null;
      return;
    }

    const valor = Number(id_cliente);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Cliente inválido");
    }

    this.id_cliente = valor;
  }

  setIdVendedor(id_vendedor) 
  {
    if (id_vendedor === null || id_vendedor === undefined || id_vendedor === "") 
    {
      this.id_vendedor = null;
      return;
    }

    const valor = Number(id_vendedor);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Vendedor inválido");
    }

    this.id_vendedor = valor;
  }

  setValorTotal(valor_total) 
  {
    const valor = Number(valor_total);

    if (!Number.isFinite(valor) || valor < 0) 
    {
      throw new Error("Valor total inválido");
    }

    this.valor_total = valor;
  }

  setFormaPagamento(forma_pagamento) 
  {
    const valor = String(forma_pagamento).trim().toUpperCase();

    if (!Object.values(FormaPagamentoVenda).includes(valor)) 
    {
      throw new Error("Forma de pagamento inválida");
    }

    this.forma_pagamento = valor;
  }

  setStatus(status) 
  {
    const valor = String(status).trim().toUpperCase();

    if (!Object.values(StatusVenda).includes(valor)) 
    {
      throw new Error("Status inválido");
    }

    this.status = valor;
  }
}
