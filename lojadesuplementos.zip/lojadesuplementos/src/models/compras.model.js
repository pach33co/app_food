import { StatusCompra } from "../enum/compras.enum.js";

export class CompraModel 
{
  constructor(id = 0,data_compra = "",id_fornecedor = null,valor_total = 0,status = StatusCompra.PENDENTE) 
  {
    this.id = id;
    this.setDataCompra(data_compra);
    this.setIdFornecedor(id_fornecedor);
    this.setValorTotal(valor_total);
    this.setStatus(status);
  }

  setDataCompra(data_compra) 
  {
    this.data_compra = data_compra ? String(data_compra).trim() : "";
  }

  setIdFornecedor(id_fornecedor) 
  {
    if (id_fornecedor === null || id_fornecedor === undefined || id_fornecedor === "") 
    {
      this.id_fornecedor = null;
      return;
    }

    const valor = Number(id_fornecedor);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Fornecedor inválido");
    }

    this.id_fornecedor = valor;
  }

  setValorTotal(valor_total) 
  {
    const valor = Number(valor_total);

    if (!Number.isFinite(valor) || valor < 0) 
    {
      throw new Error("Valor total inválido");
    }

    this.valor_total = valor;
  }

  setStatus(status) 
  {
    const valor = String(status).trim().toUpperCase();

    if (!Object.values(StatusCompra).includes(valor)) 
    {
      throw new Error("Status inválido");
    }

    this.status = valor;
  }
}
