export class ItemCompraModel 
{
  constructor(id = 0,id_compra = 0,id_produto = 0,quantidade = 0,preco_custo_unitario = 0) 
  {
    this.id = id;
    this.setIdCompra(id_compra);
    this.setIdProduto(id_produto);
    this.setQuantidade(quantidade);
    this.setPrecoCustoUnitario(preco_custo_unitario);
  }

  setIdCompra(id_compra) 
  {
    const valor = Number(id_compra);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Compra inválida");
    }

    this.id_compra = valor;
  }

  setIdProduto(id_produto) 
  {
    const valor = Number(id_produto);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Produto inválido");
    }

    this.id_produto = valor;
  }

  setQuantidade(quantidade) 
  {
    const valor = Number(quantidade);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Quantidade inválida");
    }

    this.quantidade = valor;
  }

  setPrecoCustoUnitario(preco_custo_unitario) 
  {
    const valor = Number(preco_custo_unitario);

    if (!Number.isFinite(valor) || valor < 0) 
    {
      throw new Error("Preço de custo inválido");
    }

    this.preco_custo_unitario = valor;
  }
}
