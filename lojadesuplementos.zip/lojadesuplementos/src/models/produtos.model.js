import { StatusProduto } from "../enum/produtos.enum.js";

export class ProdutoModel 
{
  constructor(id = 0,nome = "",descricao = "",preco_custo = 0,preco_venda = 0,estoque = 0,unidade = "un",id_fornecedor = null,status = StatusProduto.ATIVO) 
  {
    this.id = id;
    this.setNome(nome);
    this.setDescricao(descricao);
    this.setPrecoCusto(preco_custo);
    this.setPrecoVenda(preco_venda);
    this.setEstoque(estoque);
    this.setUnidade(unidade);
    this.setIdFornecedor(id_fornecedor);
    this.setStatus(status);
  }

  setNome(nome) 
  {
    const texto = String(nome).trim();

    if (!texto || texto.length < 2 || texto.length > 100) 
    {
      throw new Error("Nome inválido");
    }

    this.nome = texto;
  }

  setDescricao(descricao) 
  {
    this.descricao = descricao ? String(descricao).trim() : "";
  }

  setPrecoCusto(preco_custo) 
  {
    const valor = Number(preco_custo);

    if (!Number.isFinite(valor) || valor < 0) 
    {
      throw new Error("Preço de custo inválido");
    }

    this.preco_custo = valor;
  }

  setPrecoVenda(preco_venda) 
  {
    const valor = Number(preco_venda);

    if (!Number.isFinite(valor) || valor < 0) 
    {
      throw new Error("Preço de venda inválido");
    }

    this.preco_venda = valor;
  }

  setEstoque(estoque) 
  {
    const valor = Number(estoque);

    if (!Number.isInteger(valor) || valor < 0) 
    {
      throw new Error("Estoque inválido");
    }

    this.estoque = valor;
  }

  setUnidade(unidade) 
  {
    const texto = String(unidade).trim();

    if (!texto || texto.length > 10) 
    {
      throw new Error("Unidade inválida");
    }

    this.unidade = texto;
  }

  setIdFornecedor(id_fornecedor) 
  {
    if (id_fornecedor === null || id_fornecedor === undefined || id_fornecedor === "") 
    {
      this.id_fornecedor = null;
      return;
    }

    const valor = Number(id_fornecedor);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Fornecedor inválido");
    }

    this.id_fornecedor = valor;
  }

  setStatus(status) 
  {
    const valor = String(status).trim().toUpperCase();

    if (!Object.values(StatusProduto).includes(valor)) 
    {
      throw new Error("Status inválido");
    }

    this.status = valor;
  }
}
