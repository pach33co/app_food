export class ItemVendaModel 
{
  constructor(id = 0,id_venda = 0,id_produto = 0,quantidade = 0,preco_unitario = 0) 
  {
    this.id = id;
    this.setIdVenda(id_venda);
    this.setIdProduto(id_produto);
    this.setQuantidade(quantidade);
    this.setPrecoUnitario(preco_unitario);
  }

  setIdVenda(id_venda) 
  {
    const valor = Number(id_venda);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Venda inválida");
    }

    this.id_venda = valor;
  }

  setIdProduto(id_produto) 
  {
    const valor = Number(id_produto);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Produto inválido");
    }

    this.id_produto = valor;
  }

  setQuantidade(quantidade) 
  {
    const valor = Number(quantidade);

    if (!Number.isInteger(valor) || valor <= 0) 
    {
      throw new Error("Quantidade inválida");
    }

    this.quantidade = valor;
  }

  setPrecoUnitario(preco_unitario) 
  {
    const valor = Number(preco_unitario);

    if (!Number.isFinite(valor) || valor < 0) 
    {
      throw new Error("Preço unitário inválido");
    }

    this.preco_unitario = valor;
  }
}
