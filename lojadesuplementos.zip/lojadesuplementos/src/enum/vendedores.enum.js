export const StatusVendedor = {
  ATIVO: "ATIVO",
  INATIVO: "INATIVO"
};
