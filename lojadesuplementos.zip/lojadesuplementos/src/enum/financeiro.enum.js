export const TipoFinanceiro = {
  RECEITA: "RECEITA",
  DESPESA: "DESPESA"
};

export const StatusFinanceiro = {
  PENDENTE: "PENDENTE",
  PAGO: "PAGO",
  CANCELADO: "CANCELADO"
};
