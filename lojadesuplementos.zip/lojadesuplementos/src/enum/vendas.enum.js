export const FormaPagamentoVenda = {
  DINHEIRO: "DINHEIRO",
  CARTAO_CREDITO: "CARTAO_CREDITO",
  CARTAO_DEBITO: "CARTAO_DEBITO",
  PIX: "PIX",
  BOLETO: "BOLETO"
};

export const StatusVenda = {
  PENDENTE: "PENDENTE",
  PAGO: "PAGO",
  CANCELADO: "CANCELADO"
};
