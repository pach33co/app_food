export const PerfilCliente = {
  CLIENTE: "ATIVO",
  ATIVO: "ATIVO",
  INATIVO: "INATIVO"
};
