export const StatusProduto = {
  ATIVO: "ATIVO",
  INATIVO: "INATIVO"
};
