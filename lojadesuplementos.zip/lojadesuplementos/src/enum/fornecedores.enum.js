export const StatusFornecedor = {
  ATIVO: "ATIVO",
  INATIVO: "INATIVO"
};
