export const StatusCompra = {
  PENDENTE: "PENDENTE",
  RECEBIDO: "RECEBIDO",
  CANCELADO: "CANCELADO"
};
