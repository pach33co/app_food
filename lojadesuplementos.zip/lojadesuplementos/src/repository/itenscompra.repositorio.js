import { connection } from "../config/db.context.js";
import { ItemCompraDTO } from "../dtos/itemcompra.dto.js";

export class ItensCompraRepository 
{
  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        id_compra,
        id_produto,
        quantidade,
        preco_custo_unitario,
        subtotal
      FROM itenscompra
      `
    );

    return result.map(ItemCompraDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        id_compra,
        id_produto,
        quantidade,
        preco_custo_unitario,
        subtotal
      FROM itenscompra
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return ItemCompraDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO itenscompra
      (id_compra, id_produto, quantidade, preco_custo_unitario)
      VALUES (?, ?, ?, ?)
      `,
      [
        item.id_compra,
        item.id_produto,
        item.quantidade,
        item.preco_custo_unitario
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE itenscompra SET
        id_compra = ?,
        id_produto = ?,
        quantidade = ?,
        preco_custo_unitario = ?
      WHERE id = ?
      `,
      [
        item.id_compra,
        item.id_produto,
        item.quantidade,
        item.preco_custo_unitario,
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM itenscompra WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
