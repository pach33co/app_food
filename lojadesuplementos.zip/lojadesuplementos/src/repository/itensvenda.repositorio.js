import { connection } from "../config/db.context.js";
import { ItemVendaDTO } from "../dtos/itemvenda.dto.js";

export class ItensVendaRepository 
{
  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        id_venda,
        id_produto,
        quantidade,
        preco_unitario,
        subtotal
      FROM itensvenda
      `
    );

    return result.map(ItemVendaDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        id_venda,
        id_produto,
        quantidade,
        preco_unitario,
        subtotal
      FROM itensvenda
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return ItemVendaDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO itensvenda
      (id_venda, id_produto, quantidade, preco_unitario)
      VALUES (?, ?, ?, ?)
      `,
      [
        item.id_venda,
        item.id_produto,
        item.quantidade,
        item.preco_unitario
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE itensvenda SET
        id_venda = ?,
        id_produto = ?,
        quantidade = ?,
        preco_unitario = ?
      WHERE id = ?
      `,
      [
        item.id_venda,
        item.id_produto,
        item.quantidade,
        item.preco_unitario,
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM itensvenda WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
