import { connection } from "../config/db.context.js";
import { FornecedorDTO } from "../dtos/fornecedor.dto.js";

export class FornecedoresRepository 
{
  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        razao_social,
        nome_fantasia,
        cnpj,
        email,
        telefone,
        endereco,
        UPPER(status) AS status
      FROM fornecedores
      `
    );

    return result.map(FornecedorDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        razao_social,
        nome_fantasia,
        cnpj,
        email,
        telefone,
        endereco,
        UPPER(status) AS status
      FROM fornecedores
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return FornecedorDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO fornecedores
      (razao_social, nome_fantasia, cnpj, email, telefone, endereco, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
      [
        item.razao_social,
        item.nome_fantasia,
        item.cnpj,
        item.email,
        item.telefone,
        item.endereco,
        String(item.status).toLowerCase()
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE fornecedores SET
        razao_social = ?,
        nome_fantasia = ?,
        cnpj = ?,
        email = ?,
        telefone = ?,
        endereco = ?,
        status = ?
      WHERE id = ?
      `,
      [
        item.razao_social,
        item.nome_fantasia,
        item.cnpj,
        item.email,
        item.telefone,
        item.endereco,
        String(item.status).toLowerCase(),
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM fornecedores WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
