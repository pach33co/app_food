import { connection } from "../config/db.context.js";
import { CompraDTO } from "../dtos/compra.dto.js";

export class ComprasRepository 
{
  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        data_compra,
        id_fornecedor,
        valor_total,
        UPPER(status) AS status
      FROM compras
      `
    );

    return result.map(CompraDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        data_compra,
        id_fornecedor,
        valor_total,
        UPPER(status) AS status
      FROM compras
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return CompraDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO compras
      (data_compra, id_fornecedor, valor_total, status)
      VALUES (COALESCE(NULLIF(?, ''), NOW()), ?, ?, ?)
      `,
      [
        item.data_compra,
        item.id_fornecedor,
        item.valor_total,
        String(item.status).toLowerCase()
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE compras SET
        data_compra = COALESCE(NULLIF(?, ''), data_compra),
        id_fornecedor = ?,
        valor_total = ?,
        status = ?
      WHERE id = ?
      `,
      [
        item.data_compra,
        item.id_fornecedor,
        item.valor_total,
        String(item.status).toLowerCase(),
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM compras WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
