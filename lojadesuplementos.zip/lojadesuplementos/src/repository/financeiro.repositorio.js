import { connection } from "../config/db.context.js";
import { FinanceiroDTO } from "../dtos/financeiro.dto.js";

export class FinanceiroRepository 
{

  static async buscarValorTotal() 
  {
    const [result] = await connection.query(
      `
      SELECT COALESCE(SUM(valor), 0) AS valor_total_financeiro
      FROM financeiro
      `
    );

    return {
      valor_total_financeiro: Number(result[0].valor_total_financeiro ?? 0)
    };
  }


  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        UPPER(tipo) AS tipo,
        categoria,
        descricao,
        valor,
        data_vencimento,
        data_pagamento,
        UPPER(status) AS status,
        id_venda,
        id_compra,
        id_cliente,
        id_fornecedor
      FROM financeiro
      `
    );

    return result.map(FinanceiroDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        UPPER(tipo) AS tipo,
        categoria,
        descricao,
        valor,
        data_vencimento,
        data_pagamento,
        UPPER(status) AS status,
        id_venda,
        id_compra,
        id_cliente,
        id_fornecedor
      FROM financeiro
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return FinanceiroDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO financeiro
      (tipo, categoria, descricao, valor, data_vencimento, data_pagamento, status, id_venda, id_compra, id_cliente, id_fornecedor)
      VALUES (?, ?, ?, ?, ?, NULLIF(?, ''), ?, ?, ?, ?, ?)
      `,
      [
        String(item.tipo).toLowerCase(),
        item.categoria,
        item.descricao,
        item.valor,
        item.data_vencimento,
        item.data_pagamento,
        String(item.status).toLowerCase(),
        item.id_venda,
        item.id_compra,
        item.id_cliente,
        item.id_fornecedor
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE financeiro SET
        tipo = ?,
        categoria = ?,
        descricao = ?,
        valor = ?,
        data_vencimento = ?,
        data_pagamento = NULLIF(?, ''),
        status = ?,
        id_venda = ?,
        id_compra = ?,
        id_cliente = ?,
        id_fornecedor = ?
      WHERE id = ?
      `,
      [
        String(item.tipo).toLowerCase(),
        item.categoria,
        item.descricao,
        item.valor,
        item.data_vencimento,
        item.data_pagamento,
        String(item.status).toLowerCase(),
        item.id_venda,
        item.id_compra,
        item.id_cliente,
        item.id_fornecedor,
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM financeiro WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
