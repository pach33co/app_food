import { connection } from "../config/db.context.js";
import { ProdutoDTO } from "../dtos/produto.dto.js";

export class ProdutosRepository 
{

  static async buscarValorTotalEstoque() 
  {
    const [result] = await connection.query(
      `
      SELECT COALESCE(SUM(estoque * preco_custo), 0) AS valor_total_estoque
      FROM produtos
      `
    );

    return {
      valor_total_estoque: Number(result[0].valor_total_estoque ?? 0)
    };
  }


  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        nome,
        descricao,
        preco_custo,
        preco_venda,
        estoque,
        unidade,
        id_fornecedor,
        UPPER(status) AS status
      FROM produtos
      `
    );

    return result.map(ProdutoDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        nome,
        descricao,
        preco_custo,
        preco_venda,
        estoque,
        unidade,
        id_fornecedor,
        UPPER(status) AS status
      FROM produtos
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return ProdutoDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO produtos
      (nome, descricao, preco_custo, preco_venda, estoque, unidade, id_fornecedor, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        item.nome,
        item.descricao,
        item.preco_custo,
        item.preco_venda,
        item.estoque,
        item.unidade,
        item.id_fornecedor,
        String(item.status).toLowerCase()
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE produtos SET
        nome = ?,
        descricao = ?,
        preco_custo = ?,
        preco_venda = ?,
        estoque = ?,
        unidade = ?,
        id_fornecedor = ?,
        status = ?
      WHERE id = ?
      `,
      [
        item.nome,
        item.descricao,
        item.preco_custo,
        item.preco_venda,
        item.estoque,
        item.unidade,
        item.id_fornecedor,
        String(item.status).toLowerCase(),
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM produtos WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
