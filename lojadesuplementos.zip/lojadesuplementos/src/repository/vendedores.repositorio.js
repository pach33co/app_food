import { connection } from "../config/db.context.js";
import { VendedorDTO } from "../dtos/vendedor.dto.js";

export class VendedoresRepository 
{
  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        nome,
        email,
        telefone,
        comissao_percentual,
        data_admissao,
        UPPER(status) AS status
      FROM vendedores
      `
    );

    return result.map(VendedorDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        nome,
        email,
        telefone,
        comissao_percentual,
        data_admissao,
        UPPER(status) AS status
      FROM vendedores
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return VendedorDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO vendedores
      (nome, email, telefone, comissao_percentual, data_admissao, status)
      VALUES (?, ?, ?, ?, ?, ?)
      `,
      [
        item.nome,
        item.email,
        item.telefone,
        item.comissao_percentual,
        item.data_admissao,
        String(item.status).toLowerCase()
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE vendedores SET
        nome = ?,
        email = ?,
        telefone = ?,
        comissao_percentual = ?,
        data_admissao = ?,
        status = ?
      WHERE id = ?
      `,
      [
        item.nome,
        item.email,
        item.telefone,
        item.comissao_percentual,
        item.data_admissao,
        String(item.status).toLowerCase(),
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM vendedores WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
