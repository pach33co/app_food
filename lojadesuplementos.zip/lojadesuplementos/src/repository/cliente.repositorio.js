import { connection } from "../config/db.context.js";
import { ClienteDTO } from "../dtos/cliente.dto.js";

export class ClienteRepository 
{
  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        nome,
        email,
        telefone,
        endereco AS Endereco,
        UPPER(status) AS perfil
      FROM clientes
      `
    );

    return result.map(ClienteDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        nome,
        email,
        telefone,
        endereco AS Endereco,
        UPPER(status) AS perfil
      FROM clientes
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return ClienteDTO.toResponse(result[0]);
  }

  static async buscarPorEmail(email) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        nome,
        email,
        telefone,
        endereco AS Endereco,
        UPPER(status) AS perfil
      FROM clientes
      WHERE email = ?
      `,
      [email]
    );

    if (!result.length) 
    {
      return null;
    }

    return ClienteDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO clientes
      (nome, email, telefone, endereco, data_cadastro, status)
      VALUES (?, ?, ?, ?, CURDATE(), ?)
      `,
      [
        item.nome,
        item.email,
        item.telefone,
        item.Endereco,
        String(item.perfil).toLowerCase()
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE clientes SET
        nome = ?,
        email = ?,
        telefone = ?,
        endereco = ?,
        status = ?
      WHERE id = ?
      `,
      [
        item.nome,
        item.email,
        item.telefone,
        item.Endereco,
        String(item.perfil).toLowerCase(),
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM clientes WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
