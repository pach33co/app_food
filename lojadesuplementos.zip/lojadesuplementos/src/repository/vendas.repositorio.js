import { connection } from "../config/db.context.js";
import { VendaDTO } from "../dtos/venda.dto.js";

export class VendasRepository 
{
  static async listar() 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        data_venda,
        id_cliente,
        id_vendedor,
        valor_total,
        UPPER(forma_pagamento) AS forma_pagamento,
        UPPER(status) AS status
      FROM vendas
      `
    );

    return result.map(VendaDTO.toResponse);
  }

  static async buscarPorId(id) 
  {
    const [result] = await connection.query(
      `
      SELECT
        id,
        data_venda,
        id_cliente,
        id_vendedor,
        valor_total,
        UPPER(forma_pagamento) AS forma_pagamento,
        UPPER(status) AS status
      FROM vendas
      WHERE id = ?
      `,
      [id]
    );

    if (!result.length) 
    {
      return null;
    }

    return VendaDTO.toResponse(result[0]);
  }

  static async criar(item) 
  {
    const [result] = await connection.query(
      `
      INSERT INTO vendas
      (data_venda, id_cliente, id_vendedor, valor_total, forma_pagamento, status)
      VALUES (COALESCE(NULLIF(?, ''), NOW()), ?, ?, ?, ?, ?)
      `,
      [
        item.data_venda,
        item.id_cliente,
        item.id_vendedor,
        item.valor_total,
        String(item.forma_pagamento).toLowerCase(),
        String(item.status).toLowerCase()
      ]
    );

    return result.insertId;
  }

  static async atualizar(id, item) 
  {
    const [result] = await connection.query(
      `
      UPDATE vendas SET
        data_venda = COALESCE(NULLIF(?, ''), data_venda),
        id_cliente = ?,
        id_vendedor = ?,
        valor_total = ?,
        forma_pagamento = ?,
        status = ?
      WHERE id = ?
      `,
      [
        item.data_venda,
        item.id_cliente,
        item.id_vendedor,
        item.valor_total,
        String(item.forma_pagamento).toLowerCase(),
        String(item.status).toLowerCase(),
        id
      ]
    );

    return result.affectedRows;
  }

  static async remover(id) 
  {
    const [result] = await connection.query(
      "DELETE FROM vendas WHERE id = ?",
      [id]
    );

    return result.affectedRows;
  }
}
