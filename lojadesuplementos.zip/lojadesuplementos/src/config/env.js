import "dotenv/config";

function requireEnv(name, fallback = "") 
{

  const value = process.env[name] ?? fallback;

  if (value === "") 
  {
    throw new Error(`Variável de ambiente obrigatória não informada: ${name}`);
  }
  return value;
}

export const env = {
  port: Number(process.env.PORT ?? 3000),
  dbHost: requireEnv("DB_HOST", "localhost"),
  dbPort: Number(process.env.DB_PORT ?? 3306),
  dbName: requireEnv("DB_NAME"),
  dbUser: requireEnv("DB_USER"),
  dbPassword: process.env.DB_PASSWORD ?? "",
  jwtSecret: requireEnv("JWT_SECRET"),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "1d",
};