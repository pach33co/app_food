import { ItensCompraService } from "../service/itenscompra.service.js";

export class ItensCompraController 
{
  async listar() 
  {
    const data = await ItensCompraService.listar();
    return { statusCode: 200, body: data };
  }

  async buscarPorId({ id }) 
  {
    if (!id) 
    {
      return { statusCode: 400, body: { error: "ID inválido" } };
    }

    const item = await ItensCompraService.buscarPorId(id);

    if (!item) 
    {
      return { statusCode: 404, body: { error: "Não encontrado" } };
    }

    return { statusCode: 200, body: item };
  }

  async criar({ body }) 
  {
    try 
    {
      const item = await ItensCompraService.criar(body);
      return { statusCode: 201, body: item };
    } catch (error) {
      return { statusCode: 400, body: { error: error.message } };
    }
  }

  async atualizar({ id, body }) 
  {
    if (!id) 
    {
      return { statusCode: 400, body: { error: "ID inválido" } };
    }

    try 
    {
      const item = await ItensCompraService.atualizar(id, body);

      if (!item) 
      {
        return { statusCode: 404, body: { error: "Não encontrado" } };
      }

      return { statusCode: 200, body: item };
    } catch (error) {
      return { statusCode: 400, body: { error: error.message } };
    }
  }

  async remover({ id }) 
  {
    if (!id) 
    {
      return { statusCode: 400, body: { error: "ID inválido" } };
    }

    const deleted = await ItensCompraService.remover(id);

    if (!deleted) 
    {
      return { statusCode: 404, body: { error: "Não encontrado" } };
    }

    return { statusCode: 204, body: null };
  }
}
