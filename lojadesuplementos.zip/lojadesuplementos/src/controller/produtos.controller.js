import { ProdutosService } from "../service/produtos.service.js";

export class ProdutosController 
{

  async buscarValorTotalEstoque() 
  {
    const data = await ProdutosService.buscarValorTotalEstoque();
    return { statusCode: 200, body: data };
  }


  async listar() 
  {
    const data = await ProdutosService.listar();
    return { statusCode: 200, body: data };
  }

  async buscarPorId({ id }) 
  {
    if (!id) 
    {
      return { statusCode: 400, body: { error: "ID inválido" } };
    }

    const item = await ProdutosService.buscarPorId(id);

    if (!item) 
    {
      return { statusCode: 404, body: { error: "Não encontrado" } };
    }

    return { statusCode: 200, body: item };
  }

  async criar({ body }) 
  {
    try 
    {
      const item = await ProdutosService.criar(body);
      return { statusCode: 201, body: item };
    } catch (error) {
      return { statusCode: 400, body: { error: error.message } };
    }
  }

  async atualizar({ id, body }) 
  {
    if (!id) 
    {
      return { statusCode: 400, body: { error: "ID inválido" } };
    }

    try 
    {
      const item = await ProdutosService.atualizar(id, body);

      if (!item) 
      {
        return { statusCode: 404, body: { error: "Não encontrado" } };
      }

      return { statusCode: 200, body: item };
    } catch (error) {
      return { statusCode: 400, body: { error: error.message } };
    }
  }

  async remover({ id }) 
  {
    if (!id) 
    {
      return { statusCode: 400, body: { error: "ID inválido" } };
    }

    const deleted = await ProdutosService.remover(id);

    if (!deleted) 
    {
      return { statusCode: 404, body: { error: "Não encontrado" } };
    }

    return { statusCode: 204, body: null };
  }
}
