# Loja de Suplementos API

API REST para gerenciamento de uma loja de suplementos, com módulos de clientes, fornecedores, produtos, vendedores, vendas, compras, itens de venda, itens de compra e financeiro.

## Tecnologias utilizadas

- Node.js
- Express
- MySQL
- mysql2
- dotenv
- Nodemon

## Estrutura do projeto

```bash
lojadesuplementos/
├── index.js
├── package.json
├── .env
├── database.sql
└── src/
    ├── config/
    ├── controller/
    ├── dtos/
    ├── enum/
    ├── models/
    ├── repository/
    ├── routes/
    └── service/
```

## Pré-requisitos

Antes de iniciar, tenha instalado na máquina:

- Node.js 18 ou superior
- npm
- MySQL Server
- HeidiSQL, DBeaver, phpMyAdmin ou outro gerenciador MySQL

## Instalação do projeto

### 1. Extrair o projeto
Extraia o `.zip` e entre na pasta do projeto.

### 2. Instalar as dependências
No terminal, dentro da pasta do projeto, execute:

```bash
npm install
```

### 3. Configurar variáveis de ambiente
O projeto já possui um arquivo `.env`. Confira se os dados de conexão com o MySQL estão corretos:

```env
PORT=3000
DB_HOST=localhost
DB_PORT=3306
DB_NAME=lojasuplementos
DB_USER=root
DB_PASSWORD=root
DB_LOGGING=false
JWT_SECRET=teste
```

> Ajuste principalmente `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` e `DB_NAME` conforme o seu MySQL.

## Como criar o banco de dados

O projeto já possui o arquivo `database.sql`, que cria o banco e todas as tabelas necessárias.

### Opção 1: Importar pelo HeidiSQL

1. Abra o HeidiSQL.
2. Conecte no seu servidor MySQL.
3. Clique com o botão direito na conexão ou no servidor.
4. Vá em **Run SQL file** / **Executar arquivo SQL**.
5. Selecione o arquivo `database.sql` que está na raiz do projeto.
6. Execute o script.
7. O banco `lojasuplementos` será criado automaticamente com as tabelas.

### Opção 2: Importar manualmente pelo HeidiSQL

1. Abra o arquivo `database.sql`.
2. Copie todo o conteúdo.
3. No HeidiSQL, abra uma nova aba de consulta.
4. Cole o script.
5. Execute tudo.

### Opção 3: Importar via terminal
Se preferir usar o terminal:

```bash
mysql -u root -p < database.sql
```

Se quiser informar o host e a porta:

```bash
mysql -h localhost -P 3306 -u root -p < database.sql
```

## Como iniciar o projeto

### Modo desenvolvimento
Executa a API com reinicialização automática ao salvar alterações:

```bash
npm run dev
```

### Modo normal
Executa a API normalmente:

```bash
npm start
```

Ao iniciar corretamente, o terminal deve exibir algo parecido com:

```bash
Servidor rodando em http://localhost:3000
```

## Teste rápido da API

Você pode testar se a aplicação está online acessando:

```http
GET http://localhost:3000/
```

Resposta esperada:

```json
{
  "status": "ok"
}
```

## Rotas principais da API

### Clientes
- `POST /cliente`
- `GET /cliente`
- `GET /cliente/:id`
- `PUT /cliente/:id`
- `DELETE /cliente/:id`

### Fornecedores
- `POST /fornecedores`
- `GET /fornecedores`
- `GET /fornecedores/:id`
- `PUT /fornecedores/:id`
- `DELETE /fornecedores/:id`

### Produtos
- `POST /produtos`
- `GET /produtos`
- `GET /produtos/valor-total-estoque`
- `GET /produtos/:id`
- `PUT /produtos/:id`
- `DELETE /produtos/:id`

### Vendedores
- `POST /vendedores`
- `GET /vendedores`
- `GET /vendedores/:id`
- `PUT /vendedores/:id`
- `DELETE /vendedores/:id`

### Vendas
- `POST /vendas`
- `GET /vendas`
- `GET /vendas/:id`
- `PUT /vendas/:id`
- `DELETE /vendas/:id`

### Itens de venda
- `POST /itensvenda`
- `GET /itensvenda`
- `GET /itensvenda/:id`
- `PUT /itensvenda/:id`
- `DELETE /itensvenda/:id`

### Compras
- `POST /compras`
- `GET /compras`
- `GET /compras/:id`
- `PUT /compras/:id`
- `DELETE /compras/:id`

### Itens de compra
- `POST /itenscompra`
- `GET /itenscompra`
- `GET /itenscompra/:id`
- `PUT /itenscompra/:id`
- `DELETE /itenscompra/:id`

### Financeiro
- `POST /financeiro`
- `GET /financeiro`
- `GET /financeiro/valor-total`
- `GET /financeiro/:id`
- `PUT /financeiro/:id`
- `DELETE /financeiro/:id`

## Fluxo recomendado de uso do sistema

Para evitar erro de chave estrangeira e manter o uso organizado, o ideal é seguir esta ordem:

### 1. Cadastrar fornecedores
Cadastre primeiro os fornecedores, pois os produtos e as compras podem depender deles.

Exemplo de dados:
```json
{
  "razao_social": "Suplementos XYZ LTDA",
  "nome_fantasia": "XYZ Suplementos",
  "cnpj": "12.345.678/0001-99",
  "email": "contato@xyz.com",
  "telefone": "11999999999",
  "endereco": "Rua A, 123",
  "status": "ATIVO"
}
```

### 2. Cadastrar produtos
Depois, cadastre os produtos vinculando ao `id_fornecedor`.

Exemplo:
```json
{
  "nome": "Whey Protein 900g",
  "descricao": "Suplemento proteico",
  "preco_custo": 80.00,
  "preco_venda": 129.90,
  "estoque": 20,
  "unidade": "un",
  "id_fornecedor": 1,
  "status": "ATIVO"
}
```

### 3. Cadastrar vendedores
Cadastre os vendedores que irão realizar as vendas.

Exemplo:
```json
{
  "nome": "João Silva",
  "email": "joao@loja.com",
  "telefone": "11988887777",
  "comissao_percentual": 5.00,
  "data_admissao": "2026-04-17",
  "status": "ATIVO"
}
```

### 4. Cadastrar clientes
Cadastre os clientes antes de lançar vendas.

Exemplo:
```json
{
  "nome": "Maria Souza",
  "email": "maria@email.com",
  "telefone": "11977776666",
  "Endereco": "Rua B, 456",
  "perfil": "ATIVO"
}
```

### 5. Registrar uma venda
Crie primeiro o cabeçalho da venda com cliente e vendedor.

Exemplo:
```json
{
  "id_cliente": 1,
  "id_vendedor": 1,
  "valor_total": 129.90,
  "forma_pagamento": "PIX",
  "status": "PENDENTE"
}
```

### 6. Registrar os itens da venda
Depois de criar a venda, cadastre os itens informando `id_venda` e `id_produto`.

Exemplo:
```json
{
  "id_venda": 1,
  "id_produto": 1,
  "quantidade": 1,
  "preco_unitario": 129.90
}
```

### 7. Registrar uma compra
Para entrada de mercadoria, crie uma compra vinculada a um fornecedor.

Exemplo:
```json
{
  "id_fornecedor": 1,
  "valor_total": 800.00,
  "status": "PENDENTE"
}
```

### 8. Registrar os itens da compra
Depois, registre os itens da compra com os produtos correspondentes.

Exemplo:
```json
{
  "id_compra": 1,
  "id_produto": 1,
  "quantidade": 10,
  "preco_custo_unitario": 80.00
}
```

### 9. Registrar lançamentos no financeiro
Use o módulo financeiro para controlar receitas e despesas ligadas ou não a vendas e compras.

Exemplo:
```json
{
  "tipo": "RECEITA",
  "categoria": "Venda",
  "descricao": "Recebimento da venda 1",
  "valor": 129.90,
  "data_vencimento": "2026-04-17",
  "data_pagamento": "2026-04-17",
  "status": "PAGO",
  "id_venda": 1,
  "id_cliente": 1
}
```

## Sequência prática recomendada

Na prática, a ordem mais segura é:

1. Importar o `database.sql`
2. Ajustar o `.env`
3. Executar `npm install`
4. Iniciar a API com `npm run dev`
5. Cadastrar fornecedores
6. Cadastrar produtos
7. Cadastrar vendedores
8. Cadastrar clientes
9. Criar vendas
10. Adicionar itens das vendas
11. Criar compras
12. Adicionar itens das compras
13. Lançar receitas e despesas no financeiro

## Observações importantes

### 1. O projeto não atualiza estoque automaticamente
Apesar de existir controle de produtos, compras e vendas, o código atual não mostra rotina automática para:
- baixar estoque ao vender
- aumentar estoque ao comprar
- recalcular `valor_total` de venda ou compra a partir dos itens

Ou seja: esses valores devem ser enviados corretamente nas requisições ou implementados futuramente na regra de negócio.

### 2. Atenção especial ao cadastro de clientes
No módulo de clientes, o código usa os campos `Endereco` e `perfil` internamente, enquanto a tabela no banco usa `endereco` e `status`. A implementação já tenta fazer essa conversão, mas ao testar o endpoint de clientes, use o formato mostrado neste README para evitar incompatibilidades.

### 3. Sem autenticação ativa
Existe `JWT_SECRET` no `.env`, mas no código atual não foi identificado middleware de autenticação protegendo as rotas. Portanto, a API está aberta para uso local.

## Sugestão de ferramentas para teste

Você pode testar a API usando:

- Postman
- Insomnia
- Thunder Client no VS Code
- cURL

## Exemplo com cURL

### Criar fornecedor
```bash
curl -X POST http://localhost:3000/fornecedores \
  -H "Content-Type: application/json" \
  -d '{
    "razao_social": "Suplementos XYZ LTDA",
    "nome_fantasia": "XYZ Suplementos",
    "cnpj": "12.345.678/0001-99",
    "email": "contato@xyz.com",
    "telefone": "11999999999",
    "endereco": "Rua A, 123",
    "status": "ATIVO"
  }'
```

### Listar produtos
```bash
curl http://localhost:3000/produtos
```

## Possíveis problemas ao rodar

### Erro de conexão com banco
Verifique:
- se o MySQL está ligado
- se o usuário e senha do `.env` estão corretos
- se o banco foi criado com o `database.sql`
- se a porta do MySQL está correta

### Porta 3000 ocupada
Troque a variável `PORT` no `.env` para outra porta, por exemplo:

```env
PORT=3001
```

## Autor

Esse projeto pertence a `Marco A.`.