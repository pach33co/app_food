import express from "express";
import { env } from "./src/config/env.js";
import router from "./src/routes/router.js";

const app = express();

app.use(express.json());
app.use(router);

app.listen(env.port, () => {
  console.log(`Servidor rodando em http://localhost:${env.port}`);
});